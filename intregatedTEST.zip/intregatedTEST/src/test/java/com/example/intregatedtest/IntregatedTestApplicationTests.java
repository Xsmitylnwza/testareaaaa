package com.example.intregatedtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntregatedTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
