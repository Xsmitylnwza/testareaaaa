package com.example.intregatedtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntregatedTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntregatedTestApplication.class, args);
    }

}
